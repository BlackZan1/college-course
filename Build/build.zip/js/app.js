/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/components/game.js":
/*!********************************!*\
  !*** ./src/components/game.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Game": () => (/* binding */ Game)
/* harmony export */ });
/* harmony import */ var _utils_pixi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/pixi */ "./src/utils/pixi.js");
/* harmony import */ var _player__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./player */ "./src/components/player.js");


class Game {
  app = {};
  size = [1920, 1080];
  ratio = this.size[0] / this.size[1];
  offsetY = window.innerHeight / 100 * 20;
  heroYOffset = window.innerHeight - 200;

  constructor() {
    this.app = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Application({
      width: window.innerWidth,
      height: window.innerHeight,
      backgroundColor: '#323232',
      antialias: true,
      resolution: 1
    });
    this.media = {
      attack: new Audio('public/assets/audio/attack.mp3')
    };
  }

  resize() {
    window.onresize = () => {
      this.app.renderer.resize(window.innerWidth, window.innerHeight);
      this.bg.width = window.innerWidth;
      this.bg.height = window.innerHeight;
    };
  }

  loadFiles() {
    this.app.loader.baseUrl = 'public/assets';
    this.app.loader.add('bg', 'background.png').add('shop', 'shop.png').add('playerBg', 'playerBg.png') // hero sprites
    .add('heroIdle', '/hero/idle.png').add('heroMove', '/hero/move.png').add('heroJump', '/hero/jump.png').add('heroFall', '/hero/fall.png').add('heroAttack', '/hero/attack.png').add('heroAttack2', '/hero/attack2.png').add('heroHit', '/hero/hit.png').add('heroDeath', '/hero/death.png') // enemy sprites
    .add('enemyIdle', '/enemy/idle.png').add('enemyMove', '/enemy/move.png').add('enemyJump', '/enemy/jump.png').add('enemyFall', '/enemy/fall.png').add('enemyAttack', '/enemy/attack.png').add('enemyAttack2', '/enemy/attack2.png').add('enemyHit', '/enemy/hit.png').add('enemyDeath', '/enemy/death.png');
  }

  createShop() {
    let sheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['shop'].url);
    const width = 118;
    const height = 128;
    this.shop = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.AnimatedSprite([new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height))]);
    this.shop.width = 350;
    this.shop.height = 400;
    this.shop.loop = true;
    this.shop.animationSpeed = 0.2;
    this.shop.play();
  }

  createHero() {
    const width = 200,
          height = 200;
    const idleSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroIdle'].url);
    const moveSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroMove'].url);
    const jumpSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroJump'].url);
    const fallSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroFall'].url);
    const attackSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroAttack'].url);
    const attack2Sheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroAttack2'].url);
    const hitSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroHit'].url);
    const deathSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['heroDeath'].url);
    this.updateHeroOffset();
    this.hero = new _player__WEBPACK_IMPORTED_MODULE_1__.Player({
      idle: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(6 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(7 * width, 0, width, height))],
      move: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(6 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(7 * width, 0, width, height))],
      jump: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(jumpSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(jumpSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height))],
      fall: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(fallSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(fallSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height))],
      attack: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height))],
      attack2: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height))],
      hit: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height))],
      death: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 0, width, height)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 0, width, height))]
    }, 200, this.heroYOffset, 650, 750);
    this.hero.attackSpeed = 0.45;
  }

  updateHeroOffset() {
    this.heroYOffset = window.innerHeight - 80 - window.innerHeight / 100 * 16.5;
  }

  createEnemy() {
    const width = 200,
          height = 200;
    const idleSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyIdle'].url);
    const moveSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyMove'].url);
    const jumpSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyJump'].url);
    const fallSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyFall'].url);
    const attackSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyAttack'].url);
    const attack2Sheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyAttack2'].url);
    const hitSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyHit'].url);
    const deathSheet = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.BaseTexture.from(this.app.loader.resources['enemyDeath'].url);
    this.updateHeroOffset();
    this.enemy = new _player__WEBPACK_IMPORTED_MODULE_1__.Player({
      idle: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(idleSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 10, width, height - 10))],
      move: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(6 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(moveSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(7 * width, 10, width, height - 10))],
      jump: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(jumpSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(jumpSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10))],
      fall: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(fallSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(fallSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10))],
      attack: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attackSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 10, width, height - 10))],
      attack2: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(attack2Sheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 10, width, height - 10))],
      hit: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(hitSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10))],
      death: [new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(0 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(1 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(2 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(3 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(4 * width, 10, width, height - 10)), new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture(deathSheet, new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Rectangle(5 * width, 10, width, height - 10))]
    }, window.innerWidth - 200, this.heroYOffset, 640, 640);
    this.enemy.isReverse = true;
    this.enemy.attackSpeed = 0.28;
    this.enemy.vel.isLeft = true;
  }

  createBg() {
    this.bg = new _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite(this.app.loader.resources['bg'].texture);
    this.bg.position.set(0, 0);
    this.bg.anchor.set(0, 0);
    this.bg.roundPixels = true;
  }

  initListener() {
    window.addEventListener('keydown', ev => {
      if (this.hero.isDead || this.enemy.isDead) return;

      switch (ev.key) {
        case 'd':
          this.hero.keys.right = true;

          if (this.hero.object.spriteType !== 'move') {
            this.hero.changeSprite('move');
          }

          this.hero.changeSide(false);
          break;

        case 'a':
          this.hero.keys.left = true;

          if (this.hero.object.spriteType !== 'move') {
            this.hero.changeSprite('move');
          }

          this.hero.changeSide(true);
          break;

        case ' ':
        case 'w':
          if (!this.hero.vel.isFalling) {
            this.hero.vel.y = -13;
            this.hero.changeSprite('jump');
          }

          break;

        case 's':
          if (this.hero.attackBox.isAttacking || this.hero.object.spriteType === 'hit') return;
          this.hero.attackBox.isAttacking = true;

          if (this.hero.vel.x === 0 && this.hero.vel.y === 0) {
            const randInt = Math.round(Math.random());
            const attackAudio = new Audio(`public/assets/audio/${randInt >= 1 ? 'attack' : 'attack2'}.mp3`);
            attackAudio.volume = 0.7;
            attackAudio.play();
            this.hero.changeSprite(randInt >= 1 ? 'attack' : 'attack2');
          }

          break;

        case 'ArrowLeft':
          this.enemy.keys.left = true;

          if (this.enemy.object.spriteType !== 'move') {
            this.enemy.changeSprite('move');
          }

          this.enemy.changeSide(true);
          break;

        case 'ArrowRight':
          this.enemy.keys.right = true;

          if (this.enemy.object.spriteType !== 'move') {
            this.enemy.changeSprite('move');
          }

          this.enemy.changeSide(false);
          break;

        case 'ArrowUp':
          if (!this.enemy.vel.isFalling) {
            this.enemy.vel.y = -13;
            this.enemy.changeSprite('jump');
          }

          break;

        case 'ArrowDown':
          if (this.enemy.attackBox.isAttacking || this.enemy.object.spriteType === 'hit') return;
          this.enemy.attackBox.isAttacking = true;

          if (this.enemy.vel.x === 0 && this.enemy.vel.y === 0) {
            const randInt = Math.round(Math.random());
            const attackAudio = new Audio(`public/assets/audio/${randInt >= 1 ? 'attack' : 'attack2'}.mp3`);
            attackAudio.volume = 0.7;
            attackAudio.play();
            this.enemy.changeSprite(randInt ? 'attack' : 'attack2');
          }

          break;
      }
    });
    window.addEventListener('keyup', ev => {
      if (this.hero.isDead || this.enemy.isDead) return;

      switch (ev.key) {
        case 'd':
          this.hero.keys.right = false;

          if (!this.hero.keys.left) {
            this.hero.changeSprite('idle');
          }

          break;

        case 'a':
          this.hero.keys.left = false;

          if (!this.hero.keys.right) {
            this.hero.changeSprite('idle');
          }

          break;

        case 'ArrowLeft':
          this.enemy.keys.left = false;

          if (!this.enemy.keys.right) {
            this.enemy.changeSprite('idle');
          }

          break;

        case 'ArrowRight':
          this.enemy.keys.right = false;

          if (!this.enemy.keys.left) {
            this.enemy.changeSprite('idle');
          }

          break;
      }
    });
  }

  init(node) {
    node.appendChild(this.app.view);
    this.resize();
    this.loadFiles();
    this.initListener();
    this.app.loader.load(() => {
      this.createBg();
      this.createShop();
      this.createHero();
      this.createEnemy();
      this.update();
    });
  }

  update() {
    let finished = false; // borders hero

    const b1 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    b1.height = this.hero.rectangle.height;
    b1.width = 5;
    const b2 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    b2.height = this.hero.rectangle.height;
    b2.width = 5; // borders enemy

    const b3 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    b3.height = this.enemy.rectangle.height;
    b3.width = 5;
    const b4 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    b4.height = this.enemy.rectangle.height;
    b4.width = 5;
    const bBottom = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    bBottom.height = 5;
    bBottom.width = window.innerWidth;
    const attack1 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);
    const attack2 = _utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_0__.PIXI.Texture.WHITE);

    let ticker = () => {
      if (finished) {
        document.getElementById('final').style.display = 'flex';
        return;
      }

      if (this.hero.isDead) {
        document.getElementById('player-win').textContent = 'Second player';
        setTimeout(() => {
          finished = true;
        }, 2000);
      } else if (this.enemy.isDead) {
        document.getElementById('player-win').textContent = 'First player';
        setTimeout(() => {
          finished = true;
        }, 2000);
      }

      this.updateHeroOffset(); // CALC ground height

      this.offsetY = window.innerHeight - window.innerHeight / 100 * 16.5; // UPDATE shop positioning

      this.shop.x = window.innerWidth / 100 * 25;
      this.shop.y = this.offsetY - 400; // UPDATE background size

      this.bg.width = window.innerWidth;
      this.bg.height = window.innerHeight;
      this.hero.update(this.app, this.heroYOffset, this.enemy, 'second-player');
      this.enemy.update(this.app, this.heroYOffset, this.hero, 'first-player'); // ADD components to stage

      this.app.stage.addChild(this.bg);
      this.app.stage.addChild(this.shop);
      this.app.stage.addChild(this.hero.rectangle);
      this.app.stage.addChild(this.hero.object);
      this.app.stage.addChild(this.enemy.rectangle);
      this.app.stage.addChild(this.enemy.object); // - borders hero -

      b1.x = this.hero.rectangle.x - this.hero.rectangle.width / 2;
      b1.y = this.hero.rectangle.y - this.hero.rectangle.height / 2;
      b2.x = this.hero.rectangle.x + this.hero.rectangle.width / 2 + b2.width;
      b2.y = this.hero.rectangle.y - this.hero.rectangle.height / 2;
      bBottom.y = window.innerHeight - window.innerHeight / 100 * 16.5;
      bBottom.x = 0; // this.app.stage.addChild(b1)
      // this.app.stage.addChild(b2)
      // this.app.stage.addChild(bBottom)
      // - borders -
      // - borders enemy -

      b3.x = this.enemy.rectangle.x - this.enemy.rectangle.width / 2;
      b3.y = this.enemy.rectangle.y - this.enemy.rectangle.height / 2;
      b4.x = this.enemy.rectangle.x + this.enemy.rectangle.width / 2 + b4.width;
      b4.y = this.enemy.rectangle.y - this.enemy.rectangle.height / 2; // this.app.stage.addChild(b3)
      // this.app.stage.addChild(b4)
      // - borders -

      attack1.y = -100;
      attack1.x = -100;
      attack2.y = -100;
      attack2.x = -100;
      attack1.width = this.hero.attackBox.object.width - 20;
      attack1.height = this.hero.attackBox.object.height;
      attack1.y = this.hero.attackBox.object.y;
      attack1.x = this.hero.attackBox.object.x;
      attack2.width = this.enemy.attackBox.object.width - 20;
      attack2.height = this.enemy.attackBox.object.height;
      attack2.y = this.enemy.attackBox.object.y;
      attack2.x = this.enemy.attackBox.object.x; // if(this.hero.attackBox.isAttacking) {
      //     this.app.stage.addChild(attack1)
      // }
      // if(this.enemy.attackBox.isAttacking) {
      //     this.app.stage.addChild(attack2)
      // }

      requestAnimationFrame(ticker);
    };

    ticker = ticker.bind(this);
    ticker();
  }

}

/***/ }),

/***/ "./src/components/player.js":
/*!**********************************!*\
  !*** ./src/components/player.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Player": () => (/* binding */ Player)
/* harmony export */ });
/* harmony import */ var _utils_collision__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/collision */ "./src/utils/collision.js");
/* harmony import */ var _utils_pixi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/pixi */ "./src/utils/pixi.js");


const gravity = 0.7;
const damage = 20;
const stepAudio = new Audio('public/assets/audio/step.wav');
stepAudio.volume = 0.4;
const jumpAudio = new Audio('public/assets/audio/jump.mp3');
jumpAudio.volume = 0.6;
class Player {
  health = 100;
  keys = {
    right: false,
    left: false,
    up: false,
    shift: false
  };
  attackBox = {
    isAttacking: false,
    offsetX: 85,
    offsetY: 50,
    width: 200,
    height: 50,
    object: {}
  };
  vel = {
    x: 0,
    y: 0,
    isFalling: false,
    isLeft: false
  };
  attackCount = 0;
  jumpCount = 0;
  enemyHitting = false;
  isReverse = false;
  width = 0;
  height = 0;
  idleSpeed = 0.2;
  attackSpeed = 0.45;
  isDead = false;

  constructor(sprites, offsetX, offsetY, width = 650, height = 750) {
    this.sprites = sprites;
    this.width = width;
    this.height = height;
    this.init();
    this.object.x = offsetX;
    this.object.y = offsetY;
    this.rectangle.x = this.object.x;
    this.rectangle.y = this.object.y - 18;
  }

  init() {
    this.rectangle = _utils_pixi__WEBPACK_IMPORTED_MODULE_1__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_1__.PIXI.Texture.EMPTY);
    this.rectangle.width = 100;
    this.rectangle.height = 200;
    this.rectangle.anchor.set(0.5);
    this.object = new _utils_pixi__WEBPACK_IMPORTED_MODULE_1__.PIXI.AnimatedSprite(this.sprites['idle']);
    this.changeSprite('idle');
    this.object.anchor.set(0.5);
    this.object.scale.set(1);
    this.object.loop = true;
    this.object.animationSpeed = this.idleSpeed;
    this.updateSize();
    this.attackBox.object = _utils_pixi__WEBPACK_IMPORTED_MODULE_1__.PIXI.Sprite.from(_utils_pixi__WEBPACK_IMPORTED_MODULE_1__.PIXI.Texture.WHITE);
    this.attackBox.object.width = this.attackBox.width;
    this.attackBox.object.height = this.attackBox.height;
  }

  updateSize() {
    this.object.width = this.width;
    this.object.height = this.height;
  }

  changeSprite(type) {
    if (this.object.spriteType === type) return;
    if (this.object.playing) this.object.stop();
    this.object.spriteType = type;
    this.object.textures = this.sprites[type];

    switch (type) {
      case 'idle':
        this.object.animationSpeed = this.idleSpeed;
        break;

      case 'move':
        this.object.animationSpeed = 0.35;
        break;

      case 'jump':
        this.object.animationSpeed = 0.3;
        break;

      case 'fall':
        this.object.animationSpeed = 0.3;
        break;

      case 'hit':
        this.object.animationSpeed = 0.25;
        break;

      case 'attack':
        this.object.animationSpeed = this.attackSpeed;
        break;
    }

    setTimeout(() => this.object.play(), 10);
  }

  changeHealth(dmg, id) {
    this.health -= dmg;
    const bar = document.getElementById(id).querySelector('div');
    bar.style.width = `${this.health}%`;
    console.log(bar);
    if (this.health <= 0) this.isDead = true;
  }

  changeSide(isLeft) {
    if (isLeft) {
      if (this.isReverse) this.object.scale.set(1, 1);else this.object.scale.set(-1, 1);
    } else {
      if (this.isReverse) this.object.scale.set(-1, 1);else this.object.scale.set(1, 1);
    }

    this.updateSize();
  }

  checkAttack(app, enemy, enemyBarId) {
    // SHOW attack rectangle
    if (this.attackBox.isAttacking && this.attackCount <= 17) {
      this.attackCount += 1;

      if (this.vel.isLeft) {
        this.attackBox.object.x = this.rectangle.x - this.attackBox.offsetX - 42.5 - this.rectangle.width;
      } else {
        this.attackBox.object.x = this.rectangle.x + this.attackBox.offsetX + 67.5 - this.rectangle.width / 2;
      }

      if (!this.enemyHitting && (0,_utils_collision__WEBPACK_IMPORTED_MODULE_0__.attackBoxCollision)({
        attackBox: this.attackBox.object
      }, enemy.rectangle) && !enemy.vel.y) {
        this.enemyHitting = true;
        enemy.changeSprite('hit');
        enemy.changeHealth(damage, enemyBarId);

        if (!enemy.isDead) {
          enemy.vel.x = this.vel.isLeft ? -this.rectangle.width : this.rectangle.width;
          if (enemy.keys.left || enemy.keys.right) enemy.changeSprite('move');
        }

        const randInt = Math.floor(Math.random() * 3) + 1;
        const hitAudio = new Audio(`public/assets/audio/hit${randInt === 1 ? '' : randInt}.mp3`);
        hitAudio.play();
        setTimeout(() => {
          enemy.changeSprite('idle');
        }, 250);
        console.log('hit!');
      }

      app.stage.addChild(this.attackBox.object);
    } else {
      if (this.attackBox.isAttacking) {
        this.changeSprite('idle');
        console.log('ANIMATION LOOP #4');
      }

      this.attackBox.isAttacking = false;
      this.attackCount = 0;
      this.enemyHitting = false;
    }
  }

  checkBorders() {
    const absX = this.rectangle.x;

    if (absX + this.vel.x >= window.innerWidth) {
      this.rectangle.x = this.object.x = 0;
      const tpAudio = new Audio('public/assets/audio/tp.mp3');
      tpAudio.play();
    } else if (absX + this.vel.x <= 0) {
      this.rectangle.x = this.object.x = window.innerWidth - this.rectangle.width / 3;
      const tpAudio = new Audio('public/assets/audio/tp.mp3');
      tpAudio.play();
    }
  }

  update(app, yOffset, enemy, enemyBarId) {
    if (this.isDead) {
      this.object.y = yOffset;

      if (this.object.spriteType !== 'death') {
        this.object.loop = false;
        this.changeSprite('death');
      }

      return;
    }

    if (this.vel.x || this.vel.y) {
      this.attackBox.isAttacking = false;
    } // JUMP


    if (this.object.y + this.object.height + this.vel.y >= yOffset + this.object.height && this.jumpCount <= 2) {
      if (this.vel.isFalling) {
        this.changeSprite('idle');
        stepAudio.play();

        if (this.keys.right || this.keys.left) {
          this.changeSprite('move');
        }

        console.log('ANIMATION LOOP #1');
      }

      this.vel.y = 0;
      this.jumpCount = 0;
      this.object.y = yOffset;
      this.vel.isFalling = false;
    } else {
      if (this.vel.isFalling) {
        this.changeSprite('fall');
        console.log('ANIMATION LOOP #2');
        this.vel.y += gravity;
        this.vel.isFalling = true;
      } else {
        this.changeSprite('jump');
        jumpAudio.play();
        console.log('ANIMATION LOOP #3');
        setTimeout(() => {
          this.vel.y += gravity;
          this.vel.isFalling = true;
        }, 250);
      }
    }

    this.checkBorders();

    if (this.vel.x && !this.vel.y) {
      setTimeout(() => {
        stepAudio.play();
      }, 100);
    } // UPDATE player position


    this.rectangle.x += this.vel.x;
    this.rectangle.y = this.object.y - 18; // - hero -

    this.object.x += this.vel.x;
    this.object.y += this.vel.y; // UPDATE attack position

    this.attackBox.object.y = this.rectangle.y - this.rectangle.height / 2 + this.attackBox.offsetY; // REMOVE velocity after calc

    this.vel.x = 0;
    this.checkAttack(app, enemy, enemyBarId); // CHANGE velocity

    if (this.keys.right) {
      // if(keys.shift) playerVel.x = 10
      // else playerVel.x = 5
      this.vel.x = 12.5;
      this.vel.isLeft = false;
    }

    if (this.keys.left) {
      // if(keys.shift) playerVel.x = -10
      // else playerVel.x = -5
      this.vel.x = -12.5;
      this.vel.isLeft = true;
    }
  }

}

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "game": () => (/* binding */ game)
/* harmony export */ });
/* harmony import */ var _components_game__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/game */ "./src/components/game.js");
/* harmony import */ var _styles_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/main.scss */ "./src/styles/main.scss");
 // styles


const game = new _components_game__WEBPACK_IMPORTED_MODULE_0__.Game();
const audioEl = new Audio();
audioEl.src = 'public/assets/audio/theme.mp3';
audioEl.volume = 0.5;
audioEl.loop = true;

window.onload = () => {
  const audioBtn = document.getElementById('audio-btn');
  game.init(document.body);
  audioBtn.addEventListener('click', () => {
    audioEl.play();
  });
};

/***/ }),

/***/ "./src/utils/collision.js":
/*!********************************!*\
  !*** ./src/utils/collision.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "attackBoxCollision": () => (/* binding */ attackBoxCollision)
/* harmony export */ });
const attackBoxCollision = (rectangle1, rectangle2) => {
  return rectangle1.attackBox.x + rectangle1.attackBox.width >= rectangle2.x && rectangle1.attackBox.x <= rectangle2.x + rectangle2.width && rectangle1.attackBox.y + rectangle1.attackBox.height >= rectangle2.y && rectangle1.attackBox.y <= rectangle2.y + rectangle2.height;
};

/***/ }),

/***/ "./src/utils/pixi.js":
/*!***************************!*\
  !*** ./src/utils/pixi.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PIXI": () => (/* binding */ PIXI)
/* harmony export */ });
/* harmony import */ var pixi_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pixi.js */ "./node_modules/pixi.js/dist/esm/pixi.js");

const PIXI = pixi_js__WEBPACK_IMPORTED_MODULE_0__;

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./src/styles/main.scss":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./src/styles/main.scss ***!
  \*******************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "*{margin:0;padding:0;box-sizing:border-box}body{height:100vh;overflow-y:hidden;font-family:Georgia,\"Times New Roman\",Times,serif}canvas{position:fixed;top:0;right:0;left:0;bottom:0;z-index:1}header{z-index:6;position:fixed;width:100%;display:-webkit-flex;justify-content:space-between;padding:45px 55px;z-index:3;grid-template-columns:1fr 200px 1fr;gap:30px}header>div{font-size:20px;font-weight:bold}.container-shadow{box-shadow:inset 0px 0px 55px 40px rgba(0,0,0,.5);position:fixed;z-index:2;top:0;left:0;right:0;bottom:0}.health-bar{height:45px;width:100%;border-radius:10px;border:4px solid #99132e;position:relative;background:rgba(153,19,46,.35)}.health-bar>div{position:absolute;background:crimson;top:0;left:0;bottom:0;border-radius:5px;z-index:-1;transition:all .3s ease}.header-center{background:#fff;display:-webkit-flex;align-items:center;justify-content:center;position:relative}.header-center__icon{width:50px;height:50px;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);border:2px solid #ccc;padding:10px 7.5px;border-radius:10px;cursor:pointer;transition:all .3s ease}.header-center__icon:hover{background:rgba(0,0,0,.1)}.header-center__icon>svg{height:32px;width:32px}.final-mode{position:fixed;top:0;bottom:0;left:0;right:0;background:#000;display:-webkit-flex;justify-content:center;align-items:center;z-index:6;animation:fadeIn .5s ease}.final-mode__btn{border:5px solid crimson;padding:20px;border-radius:10px;color:#000;position:absolute;bottom:12.5vh;cursor:pointer;background:#fff;transition:all .3s ease;font-size:32px}.final-mode__btn:hover{background:#f1f1f1}.final-mode>img{height:100vh}.final-mode>h1{position:absolute;color:#000;text-shadow:2px 2px 10px rgba(255,255,255,.5);font-size:48px;top:7.5vh;background:#fff;padding:20px;border:5px solid crimson;border-left-width:10px;border-radius:10px}@keyframes fadeIn{from{opacity:0}to{opacity:1}}", "",{"version":3,"sources":["webpack://./src/styles/main.scss"],"names":[],"mappings":"AAAA,EACI,QAAA,CACA,SAAA,CACA,qBAAA,CAGJ,KACI,YAAA,CACA,iBAAA,CACA,iDAAA,CAGJ,OACI,cAAA,CACA,KAAA,CACA,OAAA,CACA,MAAA,CACA,QAAA,CACA,SAAA,CAGJ,OACI,SAAA,CACA,cAAA,CACA,UAAA,CACA,oBAAA,CACA,6BAAA,CACA,iBAAA,CACA,SAAA,CACA,mCAAA,CACA,QAAA,CAEA,WACI,cAAA,CACA,gBAAA,CAIR,kBACI,iDAAA,CACA,cAAA,CACA,SAAA,CACA,KAAA,CACA,MAAA,CACA,OAAA,CACA,QAAA,CAGJ,YACI,WAAA,CACA,UAAA,CACA,kBAAA,CACA,wBAAA,CACA,iBAAA,CACA,8BAAA,CAEA,gBACI,iBAAA,CACA,kBAAA,CACA,KAAA,CACA,MAAA,CACA,QAAA,CACA,iBAAA,CACA,UAAA,CACA,uBAAA,CAIR,eACI,eAAA,CACA,oBAAA,CACA,kBAAA,CACA,sBAAA,CACA,iBAAA,CAEA,qBACI,UAAA,CACA,WAAA,CACA,iBAAA,CACA,OAAA,CACA,QAAA,CACA,+BAAA,CACA,qBAAA,CACA,kBAAA,CACA,kBAAA,CACA,cAAA,CACA,uBAAA,CAEA,2BACI,yBAAA,CAGJ,yBACI,WAAA,CACA,UAAA,CAKZ,YACI,cAAA,CACA,KAAA,CACA,QAAA,CACA,MAAA,CACA,OAAA,CACA,eAAA,CACA,oBAAA,CACA,sBAAA,CACA,kBAAA,CACA,SAAA,CACA,yBAAA,CAEA,iBACI,wBAAA,CACA,YAAA,CACA,kBAAA,CACA,UAAA,CACA,iBAAA,CACA,aAAA,CACA,cAAA,CACA,eAAA,CACA,uBAAA,CACA,cAAA,CAEA,uBACI,kBAAA,CAIR,gBACI,YAAA,CAGJ,eACI,iBAAA,CACA,UAAA,CACA,6CAAA,CACA,cAAA,CACA,SAAA,CACA,eAAA,CACA,YAAA,CACA,wBAAA,CACA,sBAAA,CACA,kBAAA,CAIR,kBACI,KACI,SAAA,CAEJ,GACI,SAAA,CAAA","sourcesContent":["* {\n    margin: 0;\n    padding: 0;\n    box-sizing: border-box;\n}\n\nbody {\n    height: 100vh;\n    overflow-y: hidden;\n    font-family: Georgia, 'Times New Roman', Times, serif;\n}\n\ncanvas {\n    position: fixed;\n    top: 0;\n    right: 0;\n    left: 0;\n    bottom: 0;\n    z-index: 1;\n}\n\nheader {\n    z-index: 6;\n    position: fixed;\n    width: 100%;\n    display: -webkit-flex;\n    justify-content: space-between;\n    padding: 45px 55px;\n    z-index: 3;\n    grid-template-columns: 1fr 200px 1fr;\n    gap: 30px;\n\n    & > div {\n        font-size: 20px;\n        font-weight: bold;\n    }\n}\n\n.container-shadow {\n    box-shadow: inset 0px 0px 55px 40px rgba($color: #000000, $alpha: 0.5);\n    position: fixed;\n    z-index: 2;\n    top: 0;\n    left: 0;\n    right: 0;\n    bottom: 0;\n}\n\n.health-bar {\n    height: 45px;\n    width: 100%;\n    border-radius: 10px;\n    border: 4px solid rgb(153, 19, 46);\n    position: relative;\n    background: rgba(153, 19, 46, 0.35);\n\n    & > div {\n        position: absolute;\n        background: crimson;\n        top: 0;\n        left: 0;\n        bottom: 0;\n        border-radius: 5px;\n        z-index: -1;\n        transition: all .3s ease;\n    }\n}\n\n.header-center {\n    background: #fff;\n    display: -webkit-flex;\n    align-items: center;\n    justify-content: center;\n    position: relative;\n\n    &__icon {\n        width: 50px;\n        height: 50px;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        border: 2px solid #ccc;\n        padding: 10px 7.5px;\n        border-radius: 10px;\n        cursor: pointer;\n        transition: all .3s ease;\n\n        &:hover {\n            background: rgba($color: #000000, $alpha: 0.1);\n        }\n\n        & > svg {\n            height: 32px;\n            width: 32px;\n        }\n    }\n}\n\n.final-mode {\n    position: fixed;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    right: 0;\n    background: #000000;\n    display: -webkit-flex;\n    justify-content: center;\n    align-items: center;\n    z-index: 6;\n    animation: fadeIn .5s ease;\n\n    &__btn {\n        border: 5px solid crimson;\n        padding: 20px;\n        border-radius: 10px;\n        color: #000;\n        position: absolute;\n        bottom: 12.5vh;\n        cursor: pointer;\n        background: #fff;\n        transition: all .3s ease;\n        font-size: 32px;\n\n        &:hover {\n            background: #f1f1f1;\n        }\n    }\n\n    & > img {\n        height: 100vh;\n    }\n\n    & > h1 {\n        position: absolute;\n        color: #000;\n        text-shadow: 2px 2px 10px rgba($color: #fff, $alpha: 0.5);\n        font-size: 48px;\n        top: 7.5vh;\n        background: #fff;\n        padding: 20px;\n        border: 5px solid crimson;\n        border-left-width: 10px;\n        border-radius: 10px;\n    }\n}\n\n@keyframes fadeIn {\n    from {\n        opacity: 0;\n    }\n    to {\n        opacity: 1;\n    }\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/styles/main.scss":
/*!******************************!*\
  !*** ./src/styles/main.scss ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_4_use_1_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_4_use_2_main_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./main.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./src/styles/main.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_4_use_1_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_4_use_2_main_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_4_use_1_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_4_use_2_main_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_4_use_1_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_4_use_2_main_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_4_use_1_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_4_use_2_main_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"app": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkslasherio"] = self["webpackChunkslasherio"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_sour-27c827"], () => (__webpack_require__("./src/index.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=app.js.map