import { PIXI } from 'utils/pixi'

export class Scene extends PIXI.Container {
    constructor() {
        super()
        
        console.log(this)
    }
}