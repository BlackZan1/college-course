import * as PIXI_MAIN from 'pixi.js'

export const PIXI = PIXI_MAIN